-- core/keymaps.lua

-- Define convenience
local map = vim.keymap.set
local opts = { noremap = true, silent = true }

-- ──────────────────────────────────────────────────────────────
-- 📄 SAVE AND QUIT COMMANDS
-- ──────────────────────────────────────────────────────────────

-- Press <leader>w to save the current file
-- e.g., if leader is <space>, press: <space> + w
map("n", "<leader>w", ":w<CR>", opts)

-- Press <leader>q to quit the current window
-- e.g., <space> + q
map("n", "<leader>q", ":q<CR>", opts)

-- Press Ctrl + s to save in normal mode (like in GUI editors)
map("n", "<C-s>", ":w<CR>", opts)

-- Press Ctrl + s to save in insert mode without leaving it
map("i", "<C-s>", "<Esc>:w<CR>i", opts)

-- ──────────────────────────────────────────────────────────────
-- 🔍 SEARCH AND CLEANUP
-- ──────────────────────────────────────────────────────────────

-- Press Escape to clear any active search highlights
-- Useful after using `/` or `*` to search
map("n", "<Esc>", "<cmd>nohlsearch<CR>", opts)

-- ──────────────────────────────────────────────────────────────
-- ⛓️ DISCIPLINE: NO ARROW KEYS
-- ──────────────────────────────────────────────────────────────

-- Disables arrow keys in normal and visual modes
-- Forces thee to learn hjkl movement
map({ "n", "v" }, "<Up>", "<NOP>", opts)
map({ "n", "v" }, "<Down>", "<NOP>", opts)
map({ "n", "v" }, "<Left>", "<NOP>", opts)
map({ "n", "v" }, "<Right>", "<NOP>", opts)

-- ──────────────────────────────────────────────────────────────
-- 🪟 WINDOW NAVIGATION (for splits)
-- ──────────────────────────────────────────────────────────────

-- Move to the left split (if any) by pressing Ctrl + h
map("n", "<C-h>", "<C-w>h", opts)

-- Move to the right split by pressing Ctrl + l
map("n", "<C-l>", "<C-w>l", opts)

-- Move to the split below with Ctrl + j
map("n", "<C-j>", "<C-w>j", opts)

-- Move to the split above with Ctrl + k
map("n", "<C-k>", "<C-w>k", opts)
-- Toggle the tree (show/hide)
vim.keymap.set("n", "<leader>e", ":NvimTreeToggle<CR>", { desc = "Toggle file tree" })

-- Focus the tree (move cursor into it)
vim.keymap.set("n", "<leader>o", ":NvimTreeFocus<CR>", { desc = "Focus file tree" })
