-- core/lazy.lua

local lazypath = vim.fn.stdpath("data") .. "/site/pack/lazy/start/lazy.nvim"
vim.opt.rtp:prepend(lazypath)

require("lazy").setup({
    -- Plugins shall be declared here
    {
    "nvim-treesitter/nvim-treesitter",
    build = ":TSUpdate", -- ensures parsers update when installed
    config = function()
        require("nvim-treesitter.configs").setup({
            ensure_installed = {
                "c", "cpp", "lua", "python", "sql"
            },
            highlight = {
                enable = true,
            },
            indent = {
                enable = true,
            },
        })
    end,
},
    {
  "nvim-tree/nvim-tree.lua",
  dependencies = {
    "nvim-tree/nvim-web-devicons", -- optional, for file icons
  },
  config = function()
    require("nvim-tree").setup({
      view = {
        width = 30,
        side = "left",
      },
      renderer = {
        group_empty = true,
      },
      filters = {
        dotfiles = false,
      },
    })
  end,
},
    {
  "nvim-lualine/lualine.nvim",
  dependencies = { "nvim-tree/nvim-web-devicons" }, -- for icons
  config = function()
    require("lualine").setup({
      options = {
        theme = "auto",
        section_separators = { left = "", right = "" },
        component_separators = { left = "", right = "" },
        icons_enabled = true,
        globalstatus = true, -- one unified statusline
      },
      sections = {
        lualine_a = { "mode" },
        lualine_b = { "branch" },
        lualine_c = { "filename" },
        lualine_x = { "encoding", "fileformat", "filetype" },
        lualine_y = { "progress" },
        lualine_z = { "location" },
      },
    })
  end,
},
    {
  "catppuccin/nvim",
  name = "catppuccin",
  priority = 1000,
  config = function()
    vim.cmd.colorscheme("catppuccin-macchiato")  -- Can be "latte", "frappe", "macchiato", "mocha"
  end,
},
    {
  "akinsho/toggleterm.nvim",
  version = "*",
  config = function()
    require("toggleterm").setup({
      open_mapping = [[<C-\>]], -- Ctrl + \
      direction = "horizontal",      -- or "float", "horizontal", "vertical", "tab"
      shade_terminals = true,
    })
  end,
},
    {
  "windwp/nvim-autopairs",
  event = "InsertEnter",
  config = function()
    require("nvim-autopairs").setup({})
  end,
},
    {
  "folke/which-key.nvim",
  config = function()
    require("which-key").setup()
  end,
},
})

